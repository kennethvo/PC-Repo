// Beams.java: Generating input files for a spiral of beams. The
//    values of n, a and alpha (in degrees) as well as the output 
//    file name are to be supplied as program arguments.
//    Uses: Point3D (Section 3.9).
import java.io.*;

public class Beams {
   public static void main(String[] args) throws IOException {
      if (args.length != 4) {
         System.out.println(
               "Supply n (> 0), a (> 0), alpha (in degrees)\n" + 
               "and a filename as program arguments.\n");
         System.exit(1);
      }
      int n = 0;
      double a = 0, alphaDeg = 0;
      try {
         n = Integer.valueOf(args[0]).intValue();
         a = Double.valueOf(args[1]).doubleValue();
         alphaDeg = Double.valueOf(args[2]).doubleValue();
         if (n <= 0 || a <= 0.5)
            throw new NumberFormatException();
      } catch (NumberFormatException e) {
         System.out.println("n must be an integer > 0");
         System.out.println("a must be a real number > 0");
         System.out.println("alpha must be a real number");
         System.exit(1);
      }
      new Steps(n, a, alphaDeg * Math.PI / 180, args[3]);
   }
}

class Steps {
   FileWriter fw;

   Steps(int n, double a, double alpha, String fileName)
         throws IOException {
      fw = new FileWriter(fileName);
      
      double width = 4;
      
      for (int i = 0; i < n; i++) {

         // x-coords for right and left edges of steps
         double xRight = 2.0 - i * a;
         double xLeft = xRight - a;
         double zBottom = i;
         double zTop = i + 1;
         
         // rotation of the steps
         double phi = i * alpha;
         double cosPhi = Math.cos(phi), sinPhi = Math.sin(phi);
         
         // bottom front right
         double x1 = xRight;
         double y1 = -width/2;
         double z1 = zBottom;
         float rotX1 = (float)(x1 * cosPhi - y1 * sinPhi);
         float rotY1 = (float)(x1 * sinPhi + y1 * cosPhi);
         fw.write((8*i+1) + " " + rotX1 + " " + rotY1 + " " + z1 + "\r\n");
         
         // bottom back right
         double x2 = xRight;
         double y2 = width/2;
         double z2 = zBottom;
         float rotX2 = (float)(x2 * cosPhi - y2 * sinPhi);
         float rotY2 = (float)(x2 * sinPhi + y2 * cosPhi);
         fw.write((8*i+2) + " " + rotX2 + " " + rotY2 + " " + z2 + "\r\n");
         
         // bottom back left
         double x3 = xLeft;
         double y3 = width/2;
         double z3 = zBottom;
         float rotX3 = (float)(x3 * cosPhi - y3 * sinPhi);
         float rotY3 = (float)(x3 * sinPhi + y3 * cosPhi);
         fw.write((8*i+3) + " " + rotX3 + " " + rotY3 + " " + z3 + "\r\n");
         
         // bottom front left
         double x4 = xLeft;
         double y4 = -width/2;
         double z4 = zBottom;
         float rotX4 = (float)(x4 * cosPhi - y4 * sinPhi);
         float rotY4 = (float)(x4 * sinPhi + y4 * cosPhi);
         fw.write((8*i+4) + " " + rotX4 + " " + rotY4 + " " + z4 + "\r\n");
         
         // top front right
         double x5 = xRight;
         double y5 = -width/2;
         double z5 = zTop;
         float rotX5 = (float)(x5 * cosPhi - y5 * sinPhi);
         float rotY5 = (float)(x5 * sinPhi + y5 * cosPhi);
         fw.write((8*i+5) + " " + rotX5 + " " + rotY5 + " " + z5 + "\r\n");
         
         // top back right
         double x6 = xRight;
         double y6 = width/2;
         double z6 = zTop;
         float rotX6 = (float)(x6 * cosPhi - y6 * sinPhi);
         float rotY6 = (float)(x6 * sinPhi + y6 * cosPhi);
         fw.write((8*i+6) + " " + rotX6 + " " + rotY6 + " " + z6 + "\r\n");
         
         // top back left
         double x7 = xLeft;
         double y7 = width/2;
         double z7 = zTop;
         float rotX7 = (float)(x7 * cosPhi - y7 * sinPhi);
         float rotY7 = (float)(x7 * sinPhi + y7 * cosPhi);
         fw.write((8*i+7) + " " + rotX7 + " " + rotY7 + " " + z7 + "\r\n");
         
         // top front left
         double x8 = xLeft;
         double y8 = -width/2;
         double z8 = zTop;
         float rotX8 = (float)(x8 * cosPhi - y8 * sinPhi);
         float rotY8 = (float)(x8 * sinPhi + y8 * cosPhi);
         fw.write((8*i+8) + " " + rotX8 + " " + rotY8 + " " + z8 + "\r\n");
      }
      
      fw.write("Faces:\r\n");
      
      for (int k = 0; k < n; k++) {
         int m = 8*k + 1;
      
         face(m, m + 4, m + 7, m + 3); // (1-5-8-4)
         face(m + 1, m + 2, m + 6, m + 5); // (2-3-7-6)
         face(m + 4, m + 5, m + 6, m + 7); // (5-6-7-8)
         face(m, m + 1, m + 2, m + 3); // (1-2-3-4)
         face(m, m + 1, m + 5, m + 4); // (1-2-6-5)
         face(m + 3, m + 2, m + 6, m + 7); // (4-3-7-8)
      }
      fw.close();
   }

   void face(int a, int b, int c, int d) throws IOException {
      fw.write(a + " " + b + " " + c + " " + d + ".\r\n");
   }
}