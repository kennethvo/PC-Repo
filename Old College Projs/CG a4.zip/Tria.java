// Tria.java: Triangle represented by its vertex numbers.

// Copied from Section 5.5 of
//    Ammeraal, L. and K. Zhang (2007). Computer Graphics for Java Programmers, 2nd Edition,
//       Chichester: John Wiley.

class Tria {int iA, iB, iC;
   Tria(int i, int j, int k){iA = i; iB = j; iC = k;}
}