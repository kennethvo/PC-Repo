// CubePers.java: A cube in perspective.

// Copied from Section 5.4 of
//    Ammeraal, L. and K. Zhang (2007). Computer Graphics for Java Programmers, 2nd Edition,
//       Chichester: John Wiley.

// Uses: Point2D (Section 1.5), Point3D (Section 3.9).

import java.awt.*;
import java.awt.event.*;
import java.io.*;

public class CubePers extends Frame {

   // CubePers now takes in args
   public static void main(String[] args) {new CubePers(args[0]);}

   CubePers(String fileName) {
      super("A cube in perspective");
      addWindowListener(new WindowAdapter() {
         public void windowClosing(WindowEvent e) {System.exit(0);}
      });
      setLayout(new BorderLayout());
      add("Center", new CvCubePers(fileName));
      Dimension dim = getToolkit().getScreenSize();
      setSize(dim.width / 2, dim.height / 2);
      setLocation(dim.width / 4, dim.height / 4);
      setVisible(true);
   }
}

class CvCubePers extends Canvas {
   int centerX, centerY;
   Obj obj;

   CvCubePers(String fileName) {
      obj = new Obj(fileName);
   }

   int iX(float x) {
      return Math.round(centerX + x);
   }

   int iY(float y) {
      return Math.round(centerY - y);
   }

   void line(Graphics g, int i, int j) {
      Point2D p = obj.vScr[i], q = obj.vScr[j];
      g.drawLine(iX(p.x), iY(p.y), iX(q.x), iY(q.y));
   }

   public void paint(Graphics g) {
      Dimension dim = getSize();
      int maxX = dim.width - 1, maxY = dim.height - 1, 
          minMaxXY = Math.min(maxX, maxY);
      centerX = maxX / 2; centerY = maxY / 2;
      obj.d = obj.rho * minMaxXY / obj.objSize;
      obj.eyeAndScreen();
      
      // loop the edges array instead of having them hardcoded
      for (int[] edge : obj.edges) {
         line(g, edge[0], edge[1]);
      }
   }
}

class Obj { // Contains 3D object data
   float rho, theta = 0.3F, phi = 1.3F, d, objSize, 
         v11, v12, v13, v21, v22, v23, v32, v33, v43;
                   // Elements of viewing matrix V
   Point3D[] w;    // World coordinates
   Point2D[] vScr; // Screen coordinates
   int[][] edges;  // store edge connections from file

   Obj(String fileName) {
      try {
         // read in vertz and initialize the array
         BufferedReader reader = new BufferedReader(new FileReader(fileName));
         String line;
         line = reader.readLine();
         int vertTotal = Integer.parseInt(line.trim());

         // change arg to num of vertz read in instead of 8
         w = new Point3D[vertTotal];
         vScr = new Point2D[vertTotal];
         
         // loop and read/parse VERTZ
         for (int i = 0; i < vertTotal; i++) {
            line = reader.readLine();
            String[] parseTemp = line.trim().split("\\s+");
            float x = Float.parseFloat(parseTemp[0]);
            float y = Float.parseFloat(parseTemp[1]);
            float z = Float.parseFloat(parseTemp[2]);
            w[i] = new Point3D(x, y, z);
         }
         
         line = reader.readLine();
         int edgesTotal = Integer.parseInt(line.trim());
         edges = new int[edgesTotal][2];
         
         // loop and read/parse EDGES
         for (int i = 0; i < edgesTotal; i++) {
            line = reader.readLine();
            String[] parseTemp = line.trim().split("\\s+");
            edges[i][0] = Integer.parseInt(parseTemp[0]);
            edges[i][1] = Integer.parseInt(parseTemp[1]);
         }
         
         reader.close();
         
         // calc max distance between vertz
         objSize = 0;
         for (int i = 0; i < vertTotal; i++) {
            int j = i + 1;

            while (j < vertTotal) {
               float dx = w[i].x - w[j].x;
               float dy = w[i].y - w[j].y;
               float dz = w[i].z - w[j].z;
               
               float distance = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
               
               if (distance > objSize) 
                  objSize = distance;

               j++;
            }
         }
         rho = 5 * objSize;
         
      } catch (IOException e) {
         System.out.println("read error: " + e.getMessage());
         System.exit(0);
      } catch (NumberFormatException e) {
         System.out.println("parsing error: " + e.getMessage());
         System.exit(0);
      }
   }

   void initPersp() {
      float costh = (float) Math.cos(theta), 
            sinth = (float) Math.sin(theta), 
            cosph = (float) Math.cos(phi), 
            sinph = (float) Math.sin(phi);
      v11 = -sinth; v12 = -cosph * costh; v13 = sinph * costh;
      v21 = costh;  v22 = -cosph * sinth; v23 = sinph * sinth;
                    v32 = sinph;          v33 = cosph;
                                          v43 = -rho;
   }

   void eyeAndScreen() {
      initPersp();
      for (int i = 0; i < w.length; i++) {
         Point3D p = w[i];
         float x = v11 * p.x + v21 * p.y, 
               y = v12 * p.x + v22 * p.y + v32 * p.z, 
               z = v13 * p.x + v23 * p.y + v33 * p.z + v43;
         vScr[i] = new Point2D(-d * x / z, -d * y / z);
      }
   }
}