import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;

public class Main {
    
    //
    static class Constraint {
        char var1;
        char var2;
        char operator;

        public Constraint(char var1, char operator, char var2) {
            this.var1 = var1;
            this.var2 = var2;
            this.operator = operator;
        }

        public boolean isSatisfied(Map<Character, Integer> assignment) {
            if (!assignment.containsKey(var1) || !assignment.containsKey(var2)) {
                return true; // Not fully assigned yet
            }

            int val1 = assignment.get(var1);
            int val2 = assignment.get(var2);

            switch (operator) {
                case '=': return val1 == val2;
                case '!': return val1 != val2;
                case '>': return val1 > val2;
                case '<': return val1 < val2;
                default: return false;
            }
        }

        @Override
        public String toString() {
            return var1 + " " + operator + " " + var2;
        }
    }

    public static void main(String[] args) {
        if (args.length != 3) {
            System.err.println("format has to be: java Main <var_file> <con_file> <none|fc>");
            System.exit(0);
        }

        String var = args[0];
        String con = args[1];
        String nonefc = args[2];

        // create a cspSolver instance, checks for forward checking and parses through files
        Main cspSolver = new Main();
        cspSolver.useForwardChecking = nonefc.equals("fc");
        
        try {
            cspSolver.parseVar(var);
            cspSolver.parseCon(con);
        } catch (IOException e) {
            System.err.println("files error: " + e.getMessage());
            System.exit(0);
        }
    
        cspSolver.solve();
    }

    private Map<Character, List<Integer>> originalDomains = new TreeMap<>();
    private Map<Character, Set<Character>> constraintGraph = new TreeMap<>();

    // extracts var names, domain vals and initialize domains, original domains and constraint graph
    private void parseVar(String filename) throws IOException {
        BufferedReader reader = new BufferedReader(new FileReader(filename));
        String line;

        line = reader.readLine();
        while (line != null) {
            line = line.trim();

            if (line.isEmpty()) 
                continue;

            String[] parts = line.split(":");
            char variable = parts[0].trim().charAt(0);
            String[] domainValues = parts[1].trim().split("\\s+");
                
            List<Integer> domain = new ArrayList<>();
            for (int i = 0; i < domainValues.length; i++)
                domain.add(Integer.parseInt(domainValues[i]));
                
            domains.put(variable, domain);
            originalDomains.put(variable, new ArrayList<>(domain));
            constraintGraph.put(variable, new HashSet<>());

            line = reader.readLine();
        }
        reader.close();
    }

    private List<Constraint> constraints = new ArrayList<>();

    // same as parseVar, but gets vars for each constraint, operators and adds them to the graph
    private void parseCon(String filename) throws IOException {
        BufferedReader reader = new BufferedReader(new FileReader(filename));
        String line;

        line = reader.readLine();
        while (line != null) {
            line = line.trim();

            if (line.isEmpty()) 
                continue;

            char var1 = line.charAt(0);
            char operator = line.charAt(2);
            char var2 = line.charAt(4);
            
            constraints.add(new Constraint(var1, operator, var2));
            
            // Update constraint graph
            constraintGraph.get(var1).add(var2);
            constraintGraph.get(var2).add(var1);

            line = reader.readLine();
        }
        reader.close();
    }

    private boolean useForwardChecking = false;
    private List<Character> assignmentOrder = new ArrayList<>();

    // initialize empty hashmap to represent current partial assigments of vals to variables during backtracking
    private void solve() {
        Map<Character, Integer> assignment = new HashMap<>();
        backtrack(assignment);
    }
    
    private Map<Character, List<Integer>> domains = new TreeMap<>();

    // implements backtracking alg
    private boolean backtrack(Map<Character, Integer> assignment) {

        // if all vars are assigned, solution is found
        if (assignment.size() == domains.size()) {
            print(assignment, true);
            return true;
        }

        // using heuristics select unassigned var if it doesnt pass the if statement
        Character var = selectHeuristic(assignment);
        List<Integer> orderedValues = orderValues(var, assignment);

        for (int i = 0; i < orderedValues.size(); i++) {
            Map<Character, List<Integer>> saved = null;
            
            // save current domains only if its forwardchecking
            if (useForwardChecking)
                saved = saveDomain();
            
            assignment.put(var, orderedValues.get(i));
            assignmentOrder.add(var); // track order
            
            boolean consistent = true;
            
            // validate with constraints
            for (Constraint constraint : constraints) {
                if (!constraint.isSatisfied(assignment)) {
                    consistent = false;
                    break;
                }
            }
            
            // apply it to reduce domains IF forwardchecking
            if (consistent && useForwardChecking)
                consistent = forwardCheck(var, assignment);
            
            // recurse if the assignment remains consistent, print fail if inconsistent
            if (consistent) {
                boolean result = backtrack(assignment);
                if (result)
                    return true;
            } else
                print(assignment, false);
            
            assignment.remove(var);
            assignmentOrder.remove(assignmentOrder.size() - 1); // remove from order
            
            if (useForwardChecking) {
                domains.clear();
                domains.putAll(saved);
            }
        }
        
        // if no solution found
        return false;
    }

    // follows the variable selection heuristics for backtracking
    private Character selectHeuristic(Map<Character, Integer> assignment) {
        List<Character> unassignedVar = new ArrayList<>();
        
        for (Character var : domains.keySet()) {
            if (!assignment.containsKey(var))
                unassignedVar.add(var);
        }
        
        // most constrained var: choose smallest domain
        unassignedVar.sort((var1, var2) -> {
            int size1 = domains.get(var1).size();
            int size2 = domains.get(var2).size();
            
            if (size1 != size2)
                return size1 - size2;
            
            // choose the variable that constrains the most unassigned vars
            int con1 = 0, con2 = 0;
            
            for (Character neighbor : constraintGraph.get(var1)) {
                if (!assignment.containsKey(neighbor))
                    con1++;
            }
            
            for (Character neighbor : constraintGraph.get(var2)) {
                if (!assignment.containsKey(neighbor))
                    con2++;
            }
            
            if (con1 != con2)
                return con2 - con1; // reverse order
            
            // choose the variable that comes first alphabetically
            return var1 - var2;
        });
        
        return unassignedVar.get(0);
    }

    // value ordering heuristics
    private List<Integer> orderValues(Character var, Map<Character, Integer> assignment) {
        List<Integer> values = new ArrayList<>(domains.get(var));
        
        // choose val that rules out fewest for neighbor variables
        values.sort((val1, val2) -> {
            int conflicts1 = conflictsCount(var, val1, assignment), conflicts2 = conflictsCount(var, val2, assignment);
            
            if (conflicts1 != conflicts2)
                return conflicts1 - conflicts2;
            
            // chooses smallest val
            return val1 - val2;
        });
        
        return values;
    }

    // counts how many vals would be eliminated from neighbors' domains if a particular val is assigned
    private int conflictsCount(Character var, Integer value, Map<Character, Integer> assignment) {
        int conflicts = 0;
        
        // temp assignment with the new val
        Map<Character, Integer> temp = new HashMap<>(assignment);
        temp.put(var, value);
        
        // iterate through all neighbors of var, if neighbor is already assigned, skip it
        for (Character neighbor : constraintGraph.get(var)) {
            if (assignment.containsKey(neighbor))
                continue;
            
            // if it is unassigned, initialize counter and track vals that would be eliminated from domain
            int eliminated = 0;
            for (Integer neighborVal : domains.get(neighbor)) {
                temp.put(neighbor, neighborVal);
                
                for (int i = 0; i < constraints.size(); i++) {
                    Constraint constraint = constraints.get(i);
                    // if any constraint is violated, increment and break out of constraint loop
                    if ((constraint.var1 == neighbor && constraint.var2 == var) || (constraint.var1 == var && constraint.var2 == neighbor)) {
                        if (!constraint.isSatisfied(temp)) {
                            eliminated++;
                            break;
                        }
                    }
                }
                
                temp.remove(neighbor);
            }
            
            conflicts += eliminated;
        }
        
        return conflicts;
    }

    private boolean forwardCheck(Character var, Map<Character, Integer> assignment) {
        // loop each unassigned neighbor of assigned var
        for (Character neighbor : constraintGraph.get(var)) {
            if (assignment.containsKey(neighbor)) continue;
            
            List<Integer> neighborDomain = domains.get(neighbor);
            List<Integer> valuesToRemove = new ArrayList<>();
            
            // check for inconsistency of val in the domain w current assignment
            for (int i = 0; i < neighborDomain.size(); i++) {
                assignment.put(neighbor, neighborDomain.get(i));
                boolean consistent = true;
                
                for (int j = 0; j < constraints.size(); j++) {
                    Constraint constraint = constraints.get(j);
                    if ((constraint.var1 == var && constraint.var2 == neighbor) || (constraint.var1 == neighbor && constraint.var2 == var)) {
                        if (!constraint.isSatisfied(assignment)) {
                            consistent = false;
                            break;
                        }
                    }
                }
                
                assignment.remove(neighbor);
                
                if (!consistent) valuesToRemove.add(neighborDomain.get(i));
            }
            
            neighborDomain.removeAll(valuesToRemove);
            
            if (neighborDomain.isEmpty()) return false;
        }
        
        return true;
    }

    private Map<Character, List<Integer>> saveDomain() {
        Map<Character, List<Integer>> saved = new HashMap<>();

        // save domains recursively during backtracking
        for (Map.Entry<Character, List<Integer>> entry : domains.entrySet())
            saved.put(entry.getKey(), new ArrayList<>(entry.getValue()));

        return saved;
    }


    private int branchNumber = 1;
    private void print(Map<Character, Integer> assignment, boolean solution) {
        StringBuilder str = new StringBuilder();

        str.append(branchNumber++).append(". ");
        
        boolean first = true;

        // iterate through list and track order of variables assigned during search
        for (int i = 0; i < assignmentOrder.size(); i++) {
            if (!first) {
                str.append(", ");
            }
            str.append(assignmentOrder.get(i)).append("=").append(assignment.get(assignmentOrder.get(i)));
            first = false;
        }
        
        if (!solution) 
            str.append("  ").append("failure");
        else str.append("  ").append("solution");
        
        System.out.println(str.toString());
    }
}

