import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;

public class DragonCurves extends Frame {
    public static void main(String[] args) {
        new DragonCurves();
    }

    // create the main window 
    DragonCurves() {
        super("DragonCurves");

        // close app properly
        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });

        setSize(800, 600);
        add("Center", new CanvDrag());
        setVisible(true);
    }
}

class CanvDrag extends Canvas {
    private int recLvl = 1; // recursion depth
    private float cornerRadius = 3.0f; // for smooth corners
    
    // click mouse to increase recursion depth
    CanvDrag() {
        addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent evt) {
                recLvl++;
                repaint();
            }
        });
        
        setFocusable(true);
    }
    
    // gen L-system string
    private String dragonStrGen(int n) {
        // (X, F, nil, X+YF+, -FX-Y, 90)
        String axiom = "X";
        String result = axiom;
        
        // applies the rules of strX and strY and keep F unchanged
        for (int i = 0; i < n; i++) {
            StringBuilder resultStr = new StringBuilder();
            for (int j = 0; j < result.length(); j++) {
                char ch = result.charAt(j);

                switch (ch) {
                    case 'X':
                        resultStr.append("X+YF+");
                        break;
                    case 'Y':
                        resultStr.append("-FX-Y");
                        break;
                    case 'F':
                        resultStr.append("F");
                        break;
                    default:
                        resultStr.append(ch);
                }
            }
            result = resultStr.toString();
        }
        return result;
    }
    
    public void paint(Graphics g) {
        Graphics2D g2d = (Graphics2D) g;
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        
        // gen the dragon curve string
        String dragonStr = dragonStrGen(recLvl);
        
        double minX = 0, minY = 0, maxBX = 0, maxBY = 0, x = 0, y = 0, dir = 0;
        double step = 10;
        Dimension d = getSize();
        int maxX = d.width - 1, maxY = d.height - 1;
        
        // goes through every letter of string and finds how much space curve occupies
        for (int i = 0; i < dragonStr.length(); i++) {
            char ch = dragonStr.charAt(i);
            
            if (ch == 'F') {
                x += step * Math.cos(dir * Math.PI / 180);
                y += step * Math.sin(dir * Math.PI / 180);
                
                minX = Math.min(minX, x);
                minY = Math.min(minY, y);
                maxBX = Math.max(maxBX, x);
                maxBY = Math.max(maxBY, y);

            } 
            
            else if (ch == '+') dir += 90;

            else if (ch == '-') dir -= 90;
        }
        
        // scaling and translation to fit the canvas
        double w = maxBX - minX; // width
        double h = maxBY - minY; // height
        
        double scaleX;
        if (w > 0) scaleX = (maxX - 2 * 40) / w;
        else scaleX = (maxX - 2 * 40) / 1;

        double scaleY;
        if (h > 0) scaleY = (maxY - 2 * 40) / h;
        else scaleY = (maxY - 2 * 40) / 1;

        double scale = Math.min(scaleX, scaleY);
        
        double translateX = 40 - minX * scale + (maxX - w * scale) / 2;
        double translateY = 40 - minY * scale + (maxY - h * scale) / 2;
        
        // store points and directions used to draw curve
        double[][] points = new double[dragonStr.length() + 1][3];
        int pointCount = 0;
        
        x = 0;
        y = 0;
        dir = 0;
        
        points[pointCount][0] = x;
        points[pointCount][1] = y;
        points[pointCount][2] = dir;
        pointCount++;
        
        // collect points
        for (int i = 0; i < dragonStr.length(); i++) {
            char ch = dragonStr.charAt(i);
            
            if (ch == 'F') {
                double radians = dir * Math.PI / 180;
                x += step * Math.cos(radians);
                y += step * Math.sin(radians);
                
                points[pointCount][0] = x;
                points[pointCount][1] = y;
                points[pointCount][2] = dir;
                pointCount++;
            } 
            
            else if (ch == '+') dir += 90;
            
            else if (ch == '-') dir -= 90;
        }
        
        // draw curve
        g2d.setColor(Color.BLUE);
        g2d.setStroke(new BasicStroke(2.0f));
        
        GeneralPath path = new GeneralPath();
        
        g2d.translate(translateX, translateY);
        g2d.scale(scale, scale);
        path.moveTo((float)points[0][0], (float)points[0][1]); // rounded corners
        
        for (int i = 1; i < pointCount - 1; i++) {
            double x1 = points[i][0];
            double y1 = points[i][1];
            double x0 = points[i-1][0];
            double y0 = points[i-1][1];
            double x2 = points[i+1][0];
            double y2 = points[i+1][1];
            
            // direction vectors
            double dx0 = x1 - x0;
            double dy0 = y1 - y0;
            double dx1 = x2 - x1;
            double dy1 = y2 - y1;
            
            // offset from corners
            double radius = cornerRadius / scale;
            double d0 = Math.sqrt(dx0 * dx0 + dy0 * dy0);
            double d1 = Math.sqrt(dx1 * dx1 + dy1 * dy1);
            
            // adjust offset to reduce the bending
            double offset0 = Math.min(radius, d0 / 3);
            double offset1 = Math.min(radius, d1 / 3);
            
            // control points
            double cp1x = x1 - (offset0 * dx0) / d0;
            double cp1y = y1 - (offset0 * dy0) / d0;
            double cp2x = x1 + (offset1 * dx1) / d1;
            double cp2y = y1 + (offset1 * dy1) / d1;
            
            // line to first control point
            path.lineTo((float)cp1x, (float)cp1y);
            
            // quadratic curve to second point
            path.quadTo((float)x1, (float)y1, (float)cp2x, (float)cp2y);
        }
        
        // final segment that completes path
        path.lineTo((float)points[pointCount-1][0], (float)points[pointCount-1][1]);
        g2d.draw(path);
        
        // text on screen
        g2d.setTransform(new AffineTransform());
        g2d.setColor(Color.BLACK);
        g2d.drawString("Recursion levels: " + recLvl + " (click your mouse to increase)", 20, 30);
    }
}