import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.awt.image.*;
import java.awt.font.*;

public class Gradient extends Frame {
   public static void main(String[] args) {
      new Gradient();
   }
   
   Gradient() {
      super("Gradient, Transparency, Texture");

      addWindowListener(new WindowAdapter() {
         public void windowClosing(WindowEvent e) {
            System.exit(0);
         }
      });

      setSize(800, 600);
      add("Center", new CanvGradient());
      setVisible(true);
   }
}

class CanvGradient extends Canvas {
   private BufferedImage textureImage;
   
   // create transparent composite
   private AlphaComposite makeComposite(float alpha) {
      int type = AlphaComposite.SRC_OVER;
      return(AlphaComposite.getInstance(type, alpha));
   }
   
   // checkboard pattern (similar to from Texture.java)
   private BufferedImage createTexture() {
      BufferedImage img = new BufferedImage(20, 20, BufferedImage.TYPE_INT_ARGB);
      Graphics2D gi = img.createGraphics();
      
      // transparent
      gi.setComposite(AlphaComposite.getInstance(AlphaComposite.CLEAR));
      gi.fillRect(0, 0, 20, 20);
      gi.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER));
      
      // draw the checkboard purple
      gi.setColor(new Color(255, 220, 0));
      gi.fillRect(0, 0, 10, 10);
      gi.fillRect(10, 10, 10, 10);
      
      gi.dispose();
      return img;
   }
   
   public void paint(Graphics g) {
      super.paint(g);
      Graphics2D g2 = (Graphics2D)g;
      
      // smooth rendering
      g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
      g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
      
      // create large font As
      Font letterFont = new Font("Serif", Font.BOLD, 400);
      
      if (textureImage == null) textureImage = createTexture(); // only create texture once and reuse it
      
      // take the vector outline of the letter A for the texturing and gradient stuff
      TextLayout textLayout = new TextLayout("A", letterFont, g2.getFontRenderContext());
      Shape letterShape = textLayout.getOutline(null);
      
      // translate the As to different positions
      AffineTransform t1 = AffineTransform.getTranslateInstance(150, 400);
      Shape letterA1 = t1.createTransformedShape(letterShape);
      
      AffineTransform t2 = AffineTransform.getTranslateInstance(300, 450);
      Shape letterA2 = t2.createTransformedShape(letterShape);
      
      AffineTransform t3 = AffineTransform.getTranslateInstance(450, 400);
      Shape letterA3 = t3.createTransformedShape(letterShape);
      
      // first A with black to white gradient
      GradientPaint gp1 = new GradientPaint(100, 100, Color.BLACK, 100, 500, Color.WHITE, false);
      g2.setPaint(gp1);
      g2.fill(letterA1);
      g2.setColor(Color.black);
      g2.draw(letterA1);
      
      // second A with blue to red gradient and transparency
      Composite originalComposite = g2.getComposite();
      g2.setComposite(makeComposite(0.7F));
      
      GradientPaint gp2 = new GradientPaint(300, 100, new Color(0, 0, 255), 300, 500, new Color(255, 0, 0), false);
      g2.setPaint(gp2);
      g2.fill(letterA2);
      g2.setColor(new Color(0, 0, 0, 180));
      g2.draw(letterA2);
      
      // 3. third A with yellow checkboard pattern
      g2.setComposite(makeComposite(0.9F));
      TexturePaint tp = new TexturePaint(textureImage, new Rectangle(0, 0, 20, 20));
      g2.setPaint(tp);
      g2.fill(letterA3);
      g2.setColor(new Color(0, 100, 0));
      g2.draw(letterA3);
      
      g2.setComposite(originalComposite);
   }
}