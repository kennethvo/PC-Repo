import java.awt.*;
import java.awt.event.*;
import java.util.Random;

public class Tree extends Frame {
    public static void main(String[] args) {
        new Tree();
    }

    Tree() {
        super("Fractal Tree");

        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });

        setSize(800, 700);
        add("Center", new CanvTree());
        setVisible(true);
    }
}

class CanvTree extends Canvas {
    private int level = 5;
    private Random random = new Random();

    // variation in angles and lengths
    private final double ANGLE_VAR = 0.3;
    private final double LENGTH_VAR = 0.2;
    
    CanvTree() {
        addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent evt) {
                if (evt.getButton() == MouseEvent.BUTTON3) {
                    level = Math.max(1, level - 1); // right click
                } else {
                    level = Math.min(10, level + 1); // left click
                }
                repaint();
            }
        });
    }
    
    public void paint(Graphics g) {
        Dimension d = getSize();
        int maxX = d.width - 1, maxY = d.height - 1;
        
        // initial parameters for the tree
        int startX = maxX / 2;
        int startY = maxY - 60;
        double angle = -Math.PI / 2;
        double length = maxY * 0.3;
        
        g.setColor(new Color(100, 70, 40)); // brown trunk
        drawTree(g, startX, startY, angle, length, level, 10.0);
        
        g.setColor(Color.black);
        g.drawString("Level: " + level + " (click to increase, right-click to decrease)", 20, 30);
    }
    
    private void drawTree(Graphics g, int x, int y, double angle, double length, int depth, double thickness) {
        if (depth == 0) return;
        
        double angRan = angle + (random.nextDouble() * 2 - 1) * ANGLE_VAR;
        double lenRan = length * (1.0 - (random.nextDouble() * LENGTH_VAR));
        
        // calc end points
        int x2 = x + (int)(Math.cos(angRan) * lenRan);
        int y2 = y + (int)(Math.sin(angRan) * lenRan);
        
        // calc thickness
        Graphics2D g2d = (Graphics2D) g;
        Stroke ogStroke = g2d.getStroke();
        float strokeWidth = (float)(thickness * depth / level);
        g2d.setStroke(new BasicStroke(strokeWidth, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        
        // draw and reset
        g.drawLine(x, y, x2, y2);
        g2d.setStroke(ogStroke);
        
        double newLength = length * 0.7;
        
        // right branch
        double rightAngle = angRan + Math.PI / 4 + (random.nextDouble() * 0.2 - 0.1);
        drawTree(g, x2, y2, rightAngle, newLength, depth - 1, thickness * 0.8);
        
        // left branch
        double leftAngle = angRan - Math.PI / 4 + (random.nextDouble() * 0.2 - 0.1);
        drawTree(g, x2, y2, leftAngle, newLength, depth - 1, thickness * 0.8);
    }
}