import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class square extends JPanel implements MouseListener {

    // declares points for the square's corners
    private Point A;
    private Point B;
    private Point C;
    private Point D;

    // have to include because of implementing MouseListener
    public void mousePressed(MouseEvent e) {}
    public void mouseReleased(MouseEvent e) {}
    public void mouseEntered(MouseEvent e) {}
    public void mouseExited(MouseEvent e) {}

    // create program window and mouse listener for mouse clicks
    public square() {
        setPreferredSize(new Dimension(800, 600));
        addMouseListener(this);
    }

    // if A and B are set, draw the square
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        if (A != null && B != null) {
            drawSquare(g);
        }
    }

    // draw square using drawPolygon method
    private void drawSquare(Graphics g) {
        g.setColor(Color.RED);
        int[] xPoints = {A.x, B.x, C.x, D.x};
        int[] yPoints = {A.y, B.y, C.y, D.y};
        g.drawPolygon(xPoints, yPoints, 4);
        
        // draw the labels for each point
        g.setColor(Color.BLACK);
        g.drawString("A", A.x, A.y);
        g.drawString("B", B.x, B.y);
        g.drawString("C", C.x, C.y);
        g.drawString("D", D.x, D.y);
    }

    // mouse clicks initialize A and B coordinates
    public void mouseClicked(MouseEvent e) {
        if (A == null) {
            A = e.getPoint();
        } else if (A != null) {
            B = e.getPoint();
            trigCalcs();
            repaint();
        }
    }

    // calculate square corners using trig signs
    private void trigCalcs() {
        double dx = B.x - A.x;
        double dy = B.y - A.y;
        double sideLength = Math.sqrt(dx * dx + dy * dy);
        double angle = Math.atan2(dy, dx);

        int cxTemp = (int) (B.x + sideLength * Math.sin(angle));
        int cyTemp = (int) (B.y - sideLength * Math.cos(angle));
        C = new Point(cxTemp, cyTemp);

        int dxTemp = (int) (A.x + sideLength * Math.sin(angle));
        int dyTemp = (int) (A.y - sideLength * Math.cos(angle));
        D = new Point(dxTemp, dyTemp);
    }

    // main function
    public static void main(String[] args) {
        JFrame frame = new JFrame("Square Gen");
        frame.add(new square());
        frame.pack();
        frame.setVisible(true);
    }
}

