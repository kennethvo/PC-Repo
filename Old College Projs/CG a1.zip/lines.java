/*
 * kenneth vo
 * kxv200021
 * question 1.3 for assignment 1
 */

package graphicalTest;

import javax.swing.*;
import java.awt.*;
import java.awt.geom.Line2D;

public class lines extends JPanel {
    private static final int WIDTH = 800;
    private static final int HEIGHT = 800;
    private static final int MARGIN = 30;
    

    public static void main(String[] args) {
    	// creates GUI, JFrame and centers the frame correctly on screen
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("question 1.3");
            frame.add(new lines());
            frame.pack();
            frame.setLocationRelativeTo(null);
            frame.setVisible(true);
        });
    }
    
    public lines() {
    	// sets size of window and background color, had to create separate function due to error when these two statements were in main
        setPreferredSize(new Dimension(WIDTH, HEIGHT));
        setBackground(Color.WHITE);
    }

    protected void paintComponent(Graphics g) {
    	// initializes graphics context of program using predefined width height and margin
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;

        int size = Math.min(WIDTH, HEIGHT) - 2 * MARGIN;
        int centerX = WIDTH / 2;
        int centerY = HEIGHT / 2;
        
        drawConcentricSquares(g2, centerX, centerY, size);
    }

    private void drawConcentricSquares(Graphics2D g2, int centerX, int centerY, int size) {
    	// recursively draws the squares until the size is too small
        if (size < 1) return;
        // draws regular squares before using the corner values to draw the tilted squares next
        Point[] sCorners = drawStraightSquare(g2, centerX, centerY, size);
        drawTiltedSquare(g2, sCorners);
        
        int halfSize = size / 2;
        
        drawConcentricSquares(g2, centerX, centerY, halfSize);
    }

    private Point[] drawStraightSquare(Graphics2D g2, int centerX, int centerY, int size) {
        int halfSize = size / 2;
        Point[] corners = new Point[4];
        
        // calculate corners
        corners[0] = new Point(centerX - halfSize, centerY - halfSize);
        corners[1] = new Point(centerX + halfSize, centerY - halfSize);
        corners[2] = new Point(centerX + halfSize, centerY + halfSize);
        corners[3] = new Point(centerX - halfSize, centerY + halfSize);

        // loops and draw the square
        for (int i = 0; i < 4; i++) {
            Point c = corners[i];
            Point n = corners[(i + 1) % 4];
            
            g2.draw(new Line2D.Double(c.x, c.y, n.x, n.y));
        }

        return corners;
    }

    private Point[] drawTiltedSquare(Graphics2D g2d, Point[] corners) {
        Point[] tCorners = new Point[4];
        
        // calcs midpoints of the square edges to find tilted square corners
        for (int i = 0; i < 4; i++) {
            Point current = corners[i];
            Point next = corners[(i + 1) % 4];
            tCorners[i] = new Point(
                (current.x + next.x) / 2,
                (current.y + next.y) / 2
            );
        }

        // same loop for drawing square
        for (int i = 0; i < 4; i++) {
            Point c = tCorners[i];
            Point n = tCorners[(i + 1) % 4];
            
            g2d.draw(new Line2D.Double(c.x, c.y, n.x, n.y));
        }

        return tCorners;
    }

}