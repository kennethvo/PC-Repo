/**
 * Kenneth Vo
 * kxv200021
 */

 public class Rota3DCube {
    // initialize vertices of the cube
    private static final double[][] CUBE_VERTS = {
        {0, 0, 0}, {1, 0, 0}, {1, 0, 1}, {0, 0, 1},
        {0, 1, 1}, {1, 1, 1}, {1, 1, 0}, {0, 1, 0}
    };
    
    public static void main(String[] args) {
        if (args.length != 5) {
            System.out.println("program takes 5 command-line arguments for example: java Rota3DCube 2 2 2 45 y_axis");
            System.out.println("rewrite the program to follow this format.");
            return;
        }
        
        try {
            // parse the user command
            double a1 = Double.parseDouble(args[0]);
            double a2 = Double.parseDouble(args[1]);
            double a3 = Double.parseDouble(args[2]);
            double alpha = Double.parseDouble(args[3]);
            String axis = args[4];
            
            // Validate axis parameter
            if (!axis.equals("x_axis") && !axis.equals("y_axis") && !axis.equals("z_axis")) {
                System.out.println("axis must be x_axis, y_axis, or z_axis");
                return;
            }
            
            // Display rotation parameters
            System.out.println("arbitrary point A: (" + a1 + ", " + a2 + ", " + a3 + ")");
            System.out.println("angle of rotation alpha: " + alpha + " degrees");
            System.out.println("principle axis of rotation: " + axis);
            System.out.println();
            
            // Display original vertices
            System.out.println("initial vertices of the cube before rotation:");
            display(CUBE_VERTS);
            System.out.println();
            
            // Perform rotation
            double[][] rotatedVerts = rotate(CUBE_VERTS, a1, a2, a3, alpha, axis);
            
            // Display rotated vertices
            System.out.println("vertices of the cube after rotation:");
            display(rotatedVerts);
            
        } catch (NumberFormatException e) {
            System.out.println("Error: invalid number input");
        }
    }
    
    // for loop and print all the verts
    private static void display(double[][] verts) {
        for (int i = 0; i < verts.length; i++) {
            System.out.printf("%d: %.5f, %.5f, %.5f%n", i, verts[i][0], verts[i][1], verts[i][2]);
        }
    }
    
    // rotation function
    private static double[][] rotate(double[][] verts, double a1, double a2, double a3, double alpha, String axis) {
        
        // convert the angle to radians, create rotation matrix and create rotated verts array
        double angleRad = Math.toRadians(alpha);
        double[][] rotatedMatrix = rotMatrix(angleRad, axis);
        double[][] rotatedVertices = new double[verts.length][3];
        
        // rotate each vert
        for (int i = 0; i < verts.length; i++) {
            // translate so A is the origin
            double x = verts[i][0] - a1;
            double y = verts[i][1] - a2;
            double z = verts[i][2] - a3;
            
            // multiply rotation matrix w translated coords
            double xR = rotatedMatrix[0][0] * x + rotatedMatrix[0][1] * y + rotatedMatrix[0][2] * z;
            double yR = rotatedMatrix[1][0] * x + rotatedMatrix[1][1] * y + rotatedMatrix[1][2] * z;
            double zR = rotatedMatrix[2][0] * x + rotatedMatrix[2][1] * y + rotatedMatrix[2][2] * z;
            
            // translate back to original coord system
            rotatedVertices[i][0] = xR + a1;
            rotatedVertices[i][1] = yR + a2;
            rotatedVertices[i][2] = zR + a3;
        }
        
        return rotatedVertices;
    }
    
    // rotation matrix based on principle axis and angle
    private static double[][] rotMatrix(double angle, String axis) {
        double[][] matrix = new double[3][3];
        
        double cos = Math.cos(angle);
        double sin = Math.sin(angle);
        
        // depending on axis for rotation, switch case determines what values are changed
        switch (axis) {
            case "x_axis":
                matrix[0][0] = 1;
                matrix[0][1] = 0;
                matrix[0][2] = 0;
                matrix[1][0] = 0;
                matrix[1][1] = cos;
                matrix[1][2] = -sin;
                matrix[2][0] = 0;
                matrix[2][1] = sin;
                matrix[2][2] = cos;
                break;
                
            case "y_axis":
                matrix[0][0] = cos;
                matrix[0][1] = 0;
                matrix[0][2] = sin;
                matrix[1][0] = 0;
                matrix[1][1] = 1;
                matrix[1][2] = 0;
                matrix[2][0] = -sin;
                matrix[2][1] = 0;
                matrix[2][2] = cos;
                break;
                
            case "z_axis":
                matrix[0][0] = cos;
                matrix[0][1] = -sin;
                matrix[0][2] = 0;
                matrix[1][0] = sin;
                matrix[1][1] = cos;
                matrix[1][2] = 0;
                matrix[2][0] = 0;
                matrix[2][1] = 0;
                matrix[2][2] = 1;
                break;
        }
        
        return matrix;
    }
}

