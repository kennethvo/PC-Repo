import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;

public class Main {

    static class Clause {
        Set<String> literals;
        int p1;
        int p2;
        
        public Clause(Set<String> literals) {
            this.literals = literals;
            this.p1 = 0;
            this.p2 = 0;
        }
        
        public Clause(Set<String> literals, int p1, int p2) {
            this.literals = literals;
            this.p1 = p1;
            this.p2 = p2;
        }
        
        public boolean tautology() {
            List<String> litList = new ArrayList<>(literals);

            // loop and check if clause contains both a lit and its negation
            for (int i = 0; i < litList.size(); i++) {
                String lit = litList.get(i);
                String nLit = lit.startsWith("~") ? lit.substring(1) : "~" + lit;

                if (literals.contains(nLit)) return true;
            }

            return false;
        }
        
        public String toString() {
            if (literals.isEmpty()) return "Contradiction";
            
            // sort lits for consistent output
            List<String> sortedLits = new ArrayList<>(literals);
            Collections.sort(sortedLits);
            
            StringBuilder sb = new StringBuilder();
            
            // build string of sorted lits
            for (int i = 0; i < sortedLits.size(); i++) {
                String l = sortedLits.get(i);

                if (sb.length() > 0)
                    sb.append(" ");

                sb.append(l);
            }
            return sb.toString();
        }
        
        // overrides equals method, compares clauses based on literals
        public boolean equals(Object obj) {
            if (this == obj) return true;

            if (getClass() != obj.getClass() || obj == null) return false;

            Clause other = (Clause) obj;
            return literals.equals(other.literals);
        }

        // overrides hashCode to be consistent w overrided equals
        public int hashCode() {
            return literals.hashCode();
        }
    }
    public static void main(String[] args) {
        if (args.length < 1 || args.length > 1) {
            System.out.println("correct format: java Main <path_to_kb_file>");
            System.exit(0);
        }

        try {
            // store knowledge base clauses
            List<Clause> kb = new ArrayList<>();
            Clause clauseTest = parseInput(args[0], kb);
            
            List<Clause> nClauses = negateMet(clauseTest);
            kb.addAll(nClauses);
            
            // applies res alg to KB. returns true if original clause is valid
            boolean isValid = proofLoop(kb);
            
            print(kb);
            
            // Print result
            if (isValid) 
                System.out.println("Valid");
            else 
                System.out.println("Fail");
            
        } catch (IOException e) {
            System.err.println("error: " + e.getMessage());
            System.exit(0);
        }
    }
    
    // reads in filename and KBs and stores in ArrayList
    private static Clause parseInput(String filename, List<Clause> kb) throws IOException {
        BufferedReader r = new BufferedReader(new FileReader(filename));
        String line;
        List<String> lineList = new ArrayList<>();
        
        while ((line = r.readLine()) != null) {
            line = line.trim();
            if (!line.isEmpty()) lineList.add(line);
        }

        r.close();
        
        // split line by whitespace and create new clause w literals and add to KB
        for (int i = 0; i < lineList.size() - 1; i++) {
            String[] lits = lineList.get(i).split("\\s+");
            kb.add(new Clause(new HashSet<>(Arrays.asList(lits))));
        }
        
        // processes last line as clause for test
        String[] lits = lineList.get(lineList.size() - 1).split("\\s+");
        return new Clause(new HashSet<>(Arrays.asList(lits)));
    }
    
    // removes and adds ~ for negations and creates new clause w just negated literal
    private static List<Clause> negateMet(Clause clause) {
        List<Clause> nClauses = new ArrayList<>();

        // CHANGE THIS MAYBE
        List<String> litList = new ArrayList<>(clause.literals);

        for (int i = 0; i < litList.size(); i++) {
            String lits = litList.get(i);
            Set<String> nLiterals = new HashSet<>();

            if (lits.startsWith("~")) nLiterals.add(lits.substring(1));
            else nLiterals.add("~" + lits);

            nClauses.add(new Clause(nLiterals));
        }

        return nClauses;
    }
    
    // create hashset to track unique clauses
    private static boolean proofLoop(List<Clause> kb) {
        Set<String> clauseSet = new HashSet<>();

        for (int i = 0; i < kb.size(); i++) clauseSet.add(kb.get(i).toString());
        
        // i is current clause index, j is previous clause index
        for (int i = 0; i < kb.size(); i++) {
            int j = 0;

            // nested loop, compare each clause w previous clauses
            while (j < i) {
                Clause resClause = resolve(kb.get(i), kb.get(j), i + 1, j + 1);

                // if new clause is not a tautlogy, check if it's a contradiction
                if (resClause != null && !resClause.tautology()) {
                    if (resClause.literals.isEmpty()) { 
                        kb.add(resClause);
                        return true;
                    }

                    if (!clauseSet.contains(resClause.toString())) {
                        kb.add(resClause);
                        clauseSet.add(resClause.toString());
                    }
                }
                j++;
            }
        }
        
        return false;
    }
    
    // 
    private static Clause resolve(Clause c1, Clause c2, int id1, int id2) {
        // loop each literal and compute negations / check if second clause contains negated lit
        List<String> tempList = new ArrayList<>(c1.literals);

        for (int i = 0; i < tempList.size(); i++) {
            String tLit = tempList.get(i);
            String nLit = tLit.startsWith("~") ? tLit.substring(1) : "~" + tLit;
            
            if (c2.literals.contains(nLit)) {
                // if complementary pair is found, create new set for literals of resolved clauses and add them
                Set<String> newLiterals = new HashSet<>();

                // loops through both clauses for a complementary pair
                List<String> iLits = new ArrayList<>(c1.literals);
                for (int j = 0; j < iLits.size(); j++) {
                    String l = iLits.get(j);
                    if (!l.equals(tLit)) 
                        newLiterals.add(l);
                }

                // if found, create set for literals of resolved claus and add all lits from the clause except the resolved one
                List<String> jLits = new ArrayList<>(c2.literals);
                for (int j = 0; j < jLits.size(); j++) {
                    String l = jLits.get(j);
                    if (!l.equals(nLit))
                        newLiterals.add(l);
                }
                return new Clause(newLiterals, id1, id2);
            }
        }

        return null;
    }
    
    private static void print(List<Clause> kb) {
        for (int i = 0; i < kb.size(); i++) {
            Clause c = kb.get(i);
            String pStr = "{}";

            if (c.p1 > 0 && c.p2 > 0)
                pStr = "{" + c.p1 + ", " + c.p2 + "}";
            
            System.out.println((i + 1) + ". " + c + " " + pStr);
        }
    }
    
}